package com.parsdash.monitor

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.parsdash.monitor.databinding.ActivityMainBinding

/**
 * فعالیت اصلی — نمایش داشبورد شبیه BMW و مدیریت چرخه اتصال به دنگل OBD.
 */
class MainActivity : AppCompatActivity(), BluetoothObdManager.ObdCallback {

    private lateinit var binding: ActivityMainBinding
    private var obdManager: BluetoothObdManager? = null
    private var connectedDeviceAddress: String? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            openDevicePicker()
        }
    }

    private val devicePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val address = result.data?.getStringExtra(DeviceListActivity.EXTRA_DEVICE_ADDRESS)
            if (address != null) {
                connectToAddress(address)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGauges()
        setupReadoutLabels()

        obdManager = BluetoothObdManager(this)

        binding.buttonConnect.setOnClickListener {
            if (connectedDeviceAddress != null) {
                obdManager?.disconnect()
            } else {
                requestPermissionsThenPick()
            }
        }
    }

    private fun setupGauges() {
        binding.gaugeRpm.apply {
            maxValue = 7000f
            redlineStart = 6000f
            titleLabel = getString(R.string.rpm_label)
            unitLabel = "RPM"
        }
        binding.gaugeSpeed.apply {
            maxValue = 220f
            redlineStart = 200f
            titleLabel = getString(R.string.speed_label)
            unitLabel = "km/h"
        }
    }

    private fun setupReadoutLabels() {
        binding.readoutCoolant.textReadoutLabel.text = getString(R.string.coolant_label)
        binding.readoutFuel.textReadoutLabel.text = getString(R.string.fuel_label)
        binding.readoutVoltage.textReadoutLabel.text = getString(R.string.voltage_label)
        binding.readoutIntakeTemp.textReadoutLabel.text = getString(R.string.intake_temp_label)
        binding.readoutOdometer.textReadoutLabel.text = getString(R.string.odometer_label)
    }

    private fun requestPermissionsThenPick() {
        if (PermissionUtils.hasBluetoothPermission(this)) {
            openDevicePicker()
        } else {
            permissionLauncher.launch(PermissionUtils.requiredPermissions())
        }
    }

    private fun openDevicePicker() {
        devicePickerLauncher.launch(Intent(this, DeviceListActivity::class.java))
    }

    @SuppressLint("MissingPermission")
    private fun connectToAddress(address: String) {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        val device = adapter.getRemoteDevice(address)
        connectedDeviceAddress = address
        obdManager?.connect(device)
    }

    override fun onStatusChanged(status: BluetoothObdManager.ConnectionStatus) {
        when (status) {
            BluetoothObdManager.ConnectionStatus.CONNECTING -> {
                binding.textStatus.text = getString(R.string.status_connecting)
            }
            BluetoothObdManager.ConnectionStatus.CONNECTED -> {
                binding.textStatus.text = getString(R.string.status_connected)
                binding.buttonConnect.text = getString(R.string.disconnect)
            }
            BluetoothObdManager.ConnectionStatus.DISCONNECTED -> {
                binding.textStatus.text = getString(R.string.status_disconnected)
                binding.buttonConnect.text = getString(R.string.connect)
                connectedDeviceAddress = null
            }
            BluetoothObdManager.ConnectionStatus.ERROR -> {
                binding.textStatus.text = getString(R.string.status_error)
                binding.buttonConnect.text = getString(R.string.connect)
                connectedDeviceAddress = null
            }
        }
    }

    override fun onDataUpdate(data: BluetoothObdManager.ObdSnapshot) {
        data.rpm?.let { binding.gaugeRpm.setValue(it.toFloat()) }
        data.speedKmh?.let { binding.gaugeSpeed.setValue(it.toFloat()) }

        binding.readoutCoolant.textReadoutValue.text =
            data.coolantTempC?.let { "$it°C" } ?: "—"
        binding.readoutFuel.textReadoutValue.text =
            data.fuelLevelPercent?.let { "$it%" } ?: "—"
        binding.readoutVoltage.textReadoutValue.text =
            data.batteryVoltage?.let { "%.1fV".format(it) } ?: "—"
        binding.readoutIntakeTemp.textReadoutValue.text =
            data.intakeAirTempC?.let { "$it°C" } ?: "—"
        binding.readoutOdometer.textReadoutValue.text =
            data.odometerKm?.let { "$it" } ?: getString(R.string.odometer_unsupported)
    }

    override fun onDestroy() {
        super.onDestroy()
        obdManager?.shutdown()
    }
}
