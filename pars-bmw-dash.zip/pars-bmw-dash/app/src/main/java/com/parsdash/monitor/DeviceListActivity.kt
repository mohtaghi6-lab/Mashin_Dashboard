package com.parsdash.monitor

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * صفحه انتخاب دستگاه بلوتوث از میان دستگاه‌های قبلاً جفت‌شده (Paired).
 * جفت‌سازی اولیه دنگل OBD باید از تنظیمات اندروید انجام شده باشد؛
 * این اپ فقط از میان دستگاه‌های موجود انتخاب می‌کند.
 */
class DeviceListActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_DEVICE_ADDRESS = "extra_device_address"
    }

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device_list)

        val listView = findViewById<ListView>(R.id.listDevices)
        val emptyText = findViewById<TextView>(R.id.textEmpty)

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            Toast.makeText(this, R.string.bluetooth_not_supported, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (!adapter.isEnabled) {
            Toast.makeText(this, R.string.bluetooth_disabled, Toast.LENGTH_LONG).show()
            finish()
            return
        }

        if (!PermissionUtils.hasBluetoothPermission(this)) {
            Toast.makeText(this, R.string.permission_required, Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val pairedDevices: Set<BluetoothDevice> = adapter.bondedDevices ?: emptySet()

        if (pairedDevices.isEmpty()) {
            emptyText.visibility = android.view.View.VISIBLE
        }

        val deviceList = pairedDevices.toList()
        val displayList = deviceList.map { "${it.name ?: "دستگاه ناشناس"}\n${it.address}" }

        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        listView.setOnItemClickListener { _, _, position, _ ->
            val device = deviceList[position]
            val result = Intent().apply { putExtra(EXTRA_DEVICE_ADDRESS, device.address) }
            setResult(RESULT_OK, result)
            finish()
        }
    }
}
