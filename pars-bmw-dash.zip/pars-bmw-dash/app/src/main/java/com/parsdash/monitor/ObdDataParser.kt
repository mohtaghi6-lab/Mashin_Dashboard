package com.parsdash.monitor

/**
 * پارس‌کننده پاسخ‌های OBD-II بر اساس استاندارد SAE J1979.
 * هر پاسخ به‌صورت رشته هگزادسیمال از ELM327 می‌آید، مثلاً "41 0C 1A F8"
 * که باید بایت‌های داده (بعد از حذف echo و هدر) استخراج و طبق فرمول هر PID محاسبه شود.
 */
object ObdDataParser {

    /** پاک‌سازی پاسخ خام ELM327: حذف کاراکترهای اضافه، خط جدید، پرامپت ">" و فاصله‌ها */
    fun cleanResponse(raw: String): String {
        return raw
            .replace("\r", " ")
            .replace("\n", " ")
            .replace(">", "")
            .trim()
            .uppercase()
    }

    /** استخراج بایت‌های هگز از پاسخ تمیزشده، نادیده گرفتن NO DATA / SEARCHING و غیره */
    private fun extractBytes(cleaned: String): List<Int>? {
        if (cleaned.contains("NO DATA") || cleaned.contains("SEARCHING") ||
            cleaned.contains("ERROR") || cleaned.contains("UNABLE") || cleaned.isBlank()
        ) {
            return null
        }
        val tokens = cleaned.split(" ").filter { it.isNotBlank() }
        return try {
            tokens.map { it.toInt(16) }
        } catch (e: NumberFormatException) {
            null
        }
    }

    /**
     * یافتن بایت‌های داده واقعی بعد از کد پاسخ مربوط به یک PID.
     * مثلاً برای درخواست "010C" پاسخ باید با "41 0C" شروع شود؛ بایت‌های بعد از آن داده اصلی‌اند.
     */
    private fun dataAfterResponseCode(bytes: List<Int>, mode: Int, pid: Int): List<Int>? {
        val responseMode = mode + 0x40
        val idx = bytes.indexOfFirst { it == responseMode }
        if (idx == -1 || idx + 1 >= bytes.size || bytes[idx + 1] != pid) return null
        return bytes.drop(idx + 2)
    }

    /** دور موتور (RPM) — PID 0C — فرمول: ((A*256)+B)/4 */
    fun parseRpm(raw: String): Int? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        val data = dataAfterResponseCode(bytes, 0x01, 0x0C) ?: return null
        if (data.size < 2) return null
        return ((data[0] * 256) + data[1]) / 4
    }

    /** سرعت خودرو (Speed) — PID 0D — واحد کیلومتر بر ساعت، مقدار مستقیم بایت A */
    fun parseSpeed(raw: String): Int? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        val data = dataAfterResponseCode(bytes, 0x01, 0x0D) ?: return null
        if (data.isEmpty()) return null
        return data[0]
    }

    /** دمای مایع خنک‌کننده موتور — PID 05 — فرمول: A-40 (سانتی‌گراد) */
    fun parseCoolantTemp(raw: String): Int? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        val data = dataAfterResponseCode(bytes, 0x01, 0x05) ?: return null
        if (data.isEmpty()) return null
        return data[0] - 40
    }

    /** سطح سوخت باک — PID 2F — فرمول: A*100/255 (درصد) */
    fun parseFuelLevel(raw: String): Int? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        val data = dataAfterResponseCode(bytes, 0x01, 0x2F) ?: return null
        if (data.isEmpty()) return null
        return (data[0] * 100) / 255
    }

    /** دمای هوای ورودی — PID 0F — فرمول: A-40 (سانتی‌گراد) */
    fun parseIntakeAirTemp(raw: String): Int? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        val data = dataAfterResponseCode(bytes, 0x01, 0x0F) ?: return null
        if (data.isEmpty()) return null
        return data[0] - 40
    }

    /** بار موتور محاسبه‌شده — PID 04 — فرمول: A*100/255 (درصد) */
    fun parseEngineLoad(raw: String): Int? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        val data = dataAfterResponseCode(bytes, 0x01, 0x04) ?: return null
        if (data.isEmpty()) return null
        return (data[0] * 100) / 255
    }

    /**
     * ولتاژ باتری — این از دستور اختصاصی "AT RV" خود ELM327 می‌آید (نه یک PID استاندارد OBD)
     * پاسخ نمونه: "12.6V"
     */
    fun parseBatteryVoltage(raw: String): Double? {
        val cleaned = cleanResponse(raw).replace("V", "")
        return cleaned.toDoubleOrNull()
    }

    /**
     * تلاش آزمایشی برای خواندن کیلومتر (Odometer) با PID اختصاصی حالت ۲۲ (Mode 22).
     * این پارامتر جزو استاندارد OBD نیست و پشتیبانی آن به ECU خودرو بستگی دارد.
     * اگر ECU پاسخ ندهد یا فرمت متفاوتی برگرداند، این تابع null برمی‌گرداند و UI مقدار "—" نمایش می‌دهد.
     * TODO: پس از تست روی خودروی واقعی، PID دقیق و فرمول تبدیل را بر اساس پاسخ واقعی اصلاح کنید.
     */
    fun parseOdometerExperimental(raw: String): Long? {
        val bytes = extractBytes(cleanResponse(raw)) ?: return null
        // پاسخ حالت ۲۲ با کد 62 شروع می‌شود (0x22 + 0x40)
        val idx = bytes.indexOfFirst { it == 0x62 }
        if (idx == -1 || idx + 4 >= bytes.size) return null
        val data = bytes.drop(idx + 3) // رد شدن از کد پاسخ + ۲ بایت PID
        if (data.size < 4) return null
        // فرض بر ۴ بایت بدون‌علامت بزرگ‌اندیان به‌عنوان کیلومتر خام — نیازمند تأیید میدانی
        return (data[0].toLong() shl 24) or (data[1].toLong() shl 16) or
            (data[2].toLong() shl 8) or data[3].toLong()
    }
}
