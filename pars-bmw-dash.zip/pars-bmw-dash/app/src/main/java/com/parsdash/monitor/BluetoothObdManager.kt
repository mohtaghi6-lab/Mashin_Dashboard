package com.parsdash.monitor

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * مدیریت اتصال بلوتوث کلاسیک (SPP) به دنگل ELM327 و حلقه‌ی سرشماری (Polling)
 * پارامترهای OBD-II. تمام عملیات شبکه/بلوتوث در یک ترد پس‌زمینه اجرا می‌شود و
 * نتایج از طریق [callback] روی ترد اصلی (UI) بازگردانده می‌شوند.
 */
class BluetoothObdManager(private val callback: ObdCallback) {

    companion object {
        // UUID استاندارد پروفایل SPP (Serial Port Profile) بلوتوث کلاسیک
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val READ_TIMEOUT_MS = 2000
    }

    interface ObdCallback {
        fun onStatusChanged(status: ConnectionStatus)
        fun onDataUpdate(data: ObdSnapshot)
    }

    enum class ConnectionStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

    data class ObdSnapshot(
        val rpm: Int? = null,
        val speedKmh: Int? = null,
        val coolantTempC: Int? = null,
        val fuelLevelPercent: Int? = null,
        val intakeAirTempC: Int? = null,
        val engineLoadPercent: Int? = null,
        val batteryVoltage: Double? = null,
        val odometerKm: Long? = null
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    @Volatile
    private var running = false

    private var lastSnapshot = ObdSnapshot()

    /** شروع اتصال به یک دستگاه بلوتوث جفت‌شده (Paired) با آدرس مک مشخص */
    fun connect(device: BluetoothDevice) {
        postStatus(ConnectionStatus.CONNECTING)
        executor.execute {
            try {
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                val sock = device.createRfcommSocketToServiceRecord(SPP_UUID)
                sock.connect()
                socket = sock
                input = sock.inputStream
                output = sock.outputStream

                initializeElm()
                postStatus(ConnectionStatus.CONNECTED)
                running = true
                pollLoop()
            } catch (e: IOException) {
                postStatus(ConnectionStatus.ERROR)
                closeQuietly()
            }
        }
    }

    fun disconnect() {
        running = false
        executor.execute {
            closeQuietly()
            postStatus(ConnectionStatus.DISCONNECTED)
        }
    }

    private fun closeQuietly() {
        try { input?.close() } catch (_: IOException) {}
        try { output?.close() } catch (_: IOException) {}
        try { socket?.close() } catch (_: IOException) {}
        input = null
        output = null
        socket = null
    }

    /** ارسال دستورات اولیه راه‌اندازی ELM327 (ریست، خاموش کردن اکو، تشخیص خودکار پروتکل) */
    private fun initializeElm() {
        sendCommand("ATZ")
        Thread.sleep(1000)
        sendCommand("ATE0")   // خاموش کردن اکو دستورات
        sendCommand("ATL0")   // بدون خط جدید اضافه
        sendCommand("ATS0")   // بدون فاصله اضافه در پاسخ
        sendCommand("ATH0")   // بدون نمایش هدر
        sendCommand("ATSP0")  // تشخیص خودکار پروتکل خودرو
    }

    /** ارسال یک دستور AT/OBD و دریافت پاسخ خام به‌صورت رشته */
    private fun sendCommand(command: String): String {
        val out = output ?: return ""
        val inp = input ?: return ""
        return try {
            out.write((command + "\r").toByteArray())
            out.flush()
            readResponse(inp)
        } catch (e: IOException) {
            ""
        }
    }

    /** خواندن پاسخ تا رسیدن به کاراکتر پرامپت ">" یا اتمام زمان انتظار */
    private fun readResponse(inp: InputStream): String {
        val buffer = StringBuilder()
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < READ_TIMEOUT_MS) {
            if (inp.available() > 0) {
                val b = inp.read()
                if (b == -1) break
                val c = b.toChar()
                if (c == '>') break
                buffer.append(c)
            } else {
                Thread.sleep(20)
            }
        }
        return buffer.toString()
    }

    /** حلقه اصلی سرشماری پارامترها — هر پارامتر را به نوبت می‌خواند و نتیجه تجمیعی را گزارش می‌دهد */
    private fun pollLoop() {
        while (running) {
            try {
                val rpm = ObdDataParser.parseRpm(sendCommand("010C"))
                val speed = ObdDataParser.parseSpeed(sendCommand("010D"))
                val coolant = ObdDataParser.parseCoolantTemp(sendCommand("0105"))
                val fuel = ObdDataParser.parseFuelLevel(sendCommand("012F"))
                val intakeTemp = ObdDataParser.parseIntakeAirTemp(sendCommand("010F"))
                val engineLoad = ObdDataParser.parseEngineLoad(sendCommand("0104"))
                val voltage = ObdDataParser.parseBatteryVoltage(sendCommand("ATRV"))
                val odometer = ObdDataParser.parseOdometerExperimental(sendCommand("22 A6 00"))

                lastSnapshot = ObdSnapshot(
                    rpm = rpm ?: lastSnapshot.rpm,
                    speedKmh = speed ?: lastSnapshot.speedKmh,
                    coolantTempC = coolant ?: lastSnapshot.coolantTempC,
                    fuelLevelPercent = fuel ?: lastSnapshot.fuelLevelPercent,
                    intakeAirTempC = intakeTemp ?: lastSnapshot.intakeAirTempC,
                    engineLoadPercent = engineLoad ?: lastSnapshot.engineLoadPercent,
                    batteryVoltage = voltage ?: lastSnapshot.batteryVoltage,
                    odometerKm = odometer ?: lastSnapshot.odometerKm
                )
                postData(lastSnapshot)
            } catch (e: Exception) {
                postStatus(ConnectionStatus.ERROR)
                running = false
                closeQuietly()
            }
        }
    }

    private fun postStatus(status: ConnectionStatus) {
        mainHandler.post { callback.onStatusChanged(status) }
    }

    private fun postData(data: ObdSnapshot) {
        mainHandler.post { callback.onDataUpdate(data) }
    }

    fun shutdown() {
        running = false
        executor.shutdownNow()
        closeQuietly()
    }
}
