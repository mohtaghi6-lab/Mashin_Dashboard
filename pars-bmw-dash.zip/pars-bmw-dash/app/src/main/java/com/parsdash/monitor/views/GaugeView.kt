package com.parsdash.monitor.views

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.parsdash.monitor.R
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * گیج دایره‌ای با عقربه، شبیه کلاسترهای BMW — قابل استفاده هم برای دورسنج و هم سرعت‌سنج.
 * زاویه شروع و پایان و محدوده مقدار و ناحیه قرمز (Redline) از XML یا کد قابل تنظیم است.
 */
class GaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var maxValue: Float = 8000f
    var redlineStart: Float = 6500f
    var unitLabel: String = ""
    var titleLabel: String = ""
    var valueFormatter: (Float) -> String = { it.toInt().toString() }

    private var currentValue = 0f
    private var animator: ValueAnimator? = null

    // زاویه‌ها بر حسب درجه: گیج از ۱۳۵ درجه (پایین چپ) تا ۴۰۵ درجه (پایین راست) کشیده می‌شود (چرخش ۲۷۰ درجه‌ای)
    private val startAngle = 135f
    private val sweepAngle = 270f

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = resolveColor(R.color.gauge_track)
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = resolveColor(R.color.gauge_needle)
    }
    private val redlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = resolveColor(R.color.gauge_redline)
    }
    private val needlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = resolveColor(R.color.gauge_text_primary)
    }
    private val valueTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = resolveColor(R.color.gauge_text_primary)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val titleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = resolveColor(R.color.gauge_text_secondary)
        textAlign = Paint.Align.CENTER
    }

    private fun resolveColor(resId: Int): Int =
        androidx.core.content.ContextCompat.getColor(context, resId)

    private val arcRect = RectF()

    /** به‌روزرسانی مقدار گیج با انیمیشن نرم به‌جای پرش ناگهانی عقربه */
    fun setValue(newValue: Float) {
        val target = newValue.coerceIn(0f, maxValue)
        animator?.cancel()
        animator = ValueAnimator.ofFloat(currentValue, target).apply {
            duration = 350
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                currentValue = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val strokeWidth = min(w, h) * 0.06f
        trackPaint.strokeWidth = strokeWidth
        progressPaint.strokeWidth = strokeWidth
        redlinePaint.strokeWidth = strokeWidth
        val padding = strokeWidth
        arcRect.set(padding, padding, w - padding, h - padding)
        valueTextPaint.textSize = min(w, h) * 0.16f
        titleTextPaint.textSize = min(w, h) * 0.07f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width, height) / 2f - trackPaint.strokeWidth

        // مسیر پس‌زمینه گیج (خاکستری تیره)
        canvas.drawArc(arcRect, startAngle, sweepAngle, false, trackPaint)

        // ناحیه قرمز (Redline) در انتهای گیج
        if (redlineStart < maxValue) {
            val redlineSweep = sweepAngle * ((maxValue - redlineStart) / maxValue)
            val redlineStartAngle = startAngle + sweepAngle - redlineSweep
            canvas.drawArc(arcRect, redlineStartAngle, redlineSweep, false, redlinePaint)
        }

        // مسیر پیشرفت آبی تا مقدار فعلی
        val progressSweep = sweepAngle * (currentValue / maxValue)
        canvas.drawArc(arcRect, startAngle, progressSweep, false, progressPaint)

        // عقربه
        val needleAngleDeg = startAngle + progressSweep
        val needleAngleRad = Math.toRadians(needleAngleDeg.toDouble())
        val needleLength = radius * 0.72f
        val nx = cx + needleLength * cos(needleAngleRad).toFloat()
        val ny = cy + needleLength * sin(needleAngleRad).toFloat()
        canvas.drawLine(cx, cy, nx, ny, needlePaint.apply { strokeWidth = 6f; style = Paint.Style.STROKE })
        canvas.drawCircle(cx, cy, radius * 0.06f, needlePaint.apply { style = Paint.Style.FILL })

        // متن مقدار عددی در مرکز
        canvas.drawText(valueFormatter(currentValue), cx, cy + radius * 0.42f, valueTextPaint)
        if (unitLabel.isNotEmpty()) {
            canvas.drawText(unitLabel, cx, cy + radius * 0.62f, titleTextPaint)
        }
        if (titleLabel.isNotEmpty()) {
            canvas.drawText(titleLabel, cx, cy - radius * 0.5f, titleTextPaint)
        }
    }
}
