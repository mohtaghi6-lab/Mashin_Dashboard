package com.parsdash.monitor

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * کمک‌کننده برای مدیریت مجوزهای بلوتوث بین نسخه‌های مختلف اندروید.
 * هدیونیت هدف (اندروید ۱۰) نیازی به مجوز زمان اجرا برای بلوتوث کلاسیک ندارد،
 * اما این کد برای سازگاری با نصب احتمالی روی گوشی‌های اندروید ۱۲+ نیز نوشته شده.
 */
object PermissionUtils {

    fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    fun hasBluetoothPermission(context: Context): Boolean {
        return requiredPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }
}
