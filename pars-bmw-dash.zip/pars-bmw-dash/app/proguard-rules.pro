# قوانین Proguard/R8 — فعلاً خالی، چون minifyEnabled false است
