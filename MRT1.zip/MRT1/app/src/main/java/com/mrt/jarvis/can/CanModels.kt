package com.mrt.jarvis.can

data class CanMessage(val id: Int, val data: ByteArray, val timestamp: Long = System.currentTimeMillis()) {
    fun hex(): String = data.joinToString(" ") { "%02X".format(it) }
}

/** Describes how to extract one physical value from a frame (DBC-like). */
data class CanSignal(
    val name: String, val frameId: Int, val startByte: Int, val length: Int,
    val scale: Float = 1f, val offset: Float = 0f, val bigEndian: Boolean = true,
)

enum class CanState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class CanStats(
    val state: CanState = CanState.DISCONNECTED,
    val provider: String = "none",
    val protocol: String = "unknown",
    val reason: String? = null,
    val rx: Long = 0, val tx: Long = 0, val errors: Long = 0,
    val lastFrame: CanMessage? = null,
)
