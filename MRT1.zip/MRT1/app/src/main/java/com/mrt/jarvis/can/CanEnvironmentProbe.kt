package com.mrt.jarvis.can

import android.content.Context
import android.content.pm.PackageManager
import java.io.File

/** Inspects the real device. Reports only what actually exists; invents nothing. */
object CanEnvironmentProbe {
    private val knownPackages = listOf(
        "com.xygala.canbus", "com.syu.canbus", "com.microntek.canbus",
        "com.ts.can", "com.fyt.car", "com.hzbhd.canbus"
    )

    data class Report(
        val installedCanApps: List<String>,
        val socketCan: List<String>,
        val serialDevices: List<String>,
        val readableSerial: List<String>,
    )

    fun run(ctx: Context): Report {
        val pm = ctx.packageManager
        val apps = knownPackages.filter {
            try { pm.getPackageInfo(it, 0); true } catch (e: PackageManager.NameNotFoundException) { false }
        }
        val net = File("/sys/class/net").list()?.filter { it.startsWith("can") || it.startsWith("vcan") } ?: emptyList()
        val serial = File("/dev").listFiles()?.map { it.name }
            ?.filter { it.startsWith("ttyS") || it.startsWith("ttyMT") || it.startsWith("ttyUSB") || it.startsWith("ttyACM") }
            ?.sorted() ?: emptyList()
        val readable = serial.filter { File("/dev/$it").canRead() }
        return Report(apps, net, serial, readable)
    }
}
