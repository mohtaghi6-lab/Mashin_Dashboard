package com.mrt.jarvis

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.mrt.jarvis.ai.Net
import com.mrt.jarvis.can.CanState
import com.mrt.jarvis.dashboard.*
import com.mrt.jarvis.settings.AppPrefs
import com.mrt.jarvis.settings.SettingsActivity
import com.mrt.jarvis.diagnostics.DiagnosticsActivity
import com.mrt.jarvis.vehicle.VehicleData
import com.mrt.jarvis.voice.AssistantController
import com.mrt.jarvis.voice.VoiceManager
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), VoiceManager.Callback {
    private val vm: DashboardViewModel by viewModels()
    private lateinit var gSpeed: GaugeView; private lateinit var gRpm: GaugeView
    private lateinit var tvAssistant: TextView
    private val tiles = HashMap<Int, TextView>()
    private var voice: VoiceManager? = null
    private lateinit var assistant: AssistantController
    private val h = Handler(Looper.getMainLooper())
    private val nf = NumberFormat.getInstance(Locale("fa", "IR")).apply { maximumFractionDigits = 1 }
    private val clock = object : Runnable { override fun run() { updateStatus(); h.postDelayed(this, 2000) } } // 0.5 Hz

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        gSpeed = findViewById<GaugeView>(R.id.gSpeed).apply { maxValue = 220f; label = getString(R.string.speed); unit = getString(R.string.kmh) }
        gRpm = findViewById<GaugeView>(R.id.gRpm).apply { maxValue = 8000f; redlineFrom = AppPrefs(context).redline.toFloat()
            label = getString(R.string.rpm); unit = getString(R.string.rpm_unit); formatter = { "%.1f".format(it / 1000f) } }
        tvAssistant = findViewById(R.id.tvAssistant)
        val bottom = findViewById<LinearLayout>(R.id.bottom)
        listOf(R.string.fuel, R.string.engine_temp, R.string.battery, R.string.trip, R.string.outside_temp).forEach { id ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.glass); setPadding(8, 10, 8, 10) }
            box.addView(TextView(this).apply { setText(id); setTextAppearance(R.style.Label) })
            val v = TextView(this).apply { setTextAppearance(R.style.Value); text = getString(R.string.dash) }
            box.addView(v); tiles[id] = v
            bottom.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(6, 0, 6, 0) })
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<View>(R.id.btnSettings).setOnLongClickListener { startActivity(Intent(this, DiagnosticsActivity::class.java)); true }
        findViewById<View>(R.id.btnMic).setOnClickListener { startVoice() }
        assistant = AssistantController(this, lifecycleScope, { voice }) { tvAssistant.text = it }

        vm.vehicle.observe(this, ::bind)
        vm.can.observe(this) { updateStatus() }
    }

    private fun bind(v: VehicleData) {
        gSpeed.setValue(v.speedKmh); gRpm.setValue(v.rpm)
        fun f(x: Float?, suf: String) = x?.let { nf.format(it) + suf } ?: getString(R.string.dash)
        tiles[R.string.fuel]?.text = f(v.fuelPercent, "٪")
        tiles[R.string.engine_temp]?.text = f(v.engineTempC, "°C")
        tiles[R.string.battery]?.text = f(v.batteryVolt, "V")
        tiles[R.string.trip]?.text = f(v.tripKm, " km")
        tiles[R.string.outside_temp]?.text = f(v.outsideTempC, "°C")
        findViewById<TextView>(R.id.tvGear).text = v.gear ?: ""
        findViewById<StatusIndicatorsView>(R.id.indicators).bind(v)
        findViewById<View>(R.id.tvDemo).visibility = if (v.isDemo) View.VISIBLE else View.GONE
    }

    private fun updateStatus() {
        findViewById<TextView>(R.id.tvTime).text = SimpleDateFormat("HH:mm", Locale("fa", "IR")).format(Date())
        val on = Net.online(this)
        findViewById<TextView>(R.id.tvNet).text = getString(R.string.internet) + " " + getString(if (on) R.string.online else R.string.offline)
        val gps = runCatching { getSystemService(LocationManager::class.java).isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)
        findViewById<TextView>(R.id.tvGps).text = getString(R.string.gps) + " " + getString(if (gps) R.string.online else R.string.offline)
        @Suppress("DEPRECATION") val bt = runCatching { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true }.getOrDefault(false)
        findViewById<TextView>(R.id.tvBt).text = getString(R.string.bluetooth) + " " + getString(if (bt) R.string.online else R.string.offline)
        val cs = vm.can.value
        findViewById<TextView>(R.id.tvCan).apply {
            val ok = cs?.state == CanState.CONNECTED
            text = if (ok) "CAN " + getString(R.string.can_connected) else getString(R.string.can_not_available)
            setTextColor(getColor(if (ok) R.color.green else R.color.amber))
        }
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1); return }
        if (voice == null) voice = VoiceManager(this, this)
        voice?.listen()
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g); if (g.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoice()
    }

    // Steering-wheel keys: only the voice key is consumed; volume/media/call pass through to the factory system.
    override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
        if (code == KeyEvent.KEYCODE_VOICE_ASSIST || code == KeyEvent.KEYCODE_SEARCH) { startVoice(); return true }
        return super.onKeyDown(code, e)
    }

    override fun onListening() { tvAssistant.setText(R.string.listening) }
    override fun onResult(text: String) { tvAssistant.text = text; assistant.handle(text) }
    override fun onError(code: Int) { tvAssistant.setText(if (code == -1) R.string.r_no_stt else R.string.r_not_understood) }
    override fun onTtsReady(persian: Boolean) {}

    override fun onResume() { super.onResume(); immersive(); h.post(clock)
        gRpm.redlineFrom = AppPrefs(this).redline.toFloat()
        AppPrefs(this).brightness.takeIf { it >= 0 }?.let { window.attributes = window.attributes.apply { screenBrightness = it / 100f } } }
    override fun onPause() { h.removeCallbacks(clock); super.onPause() }
    override fun onDestroy() { voice?.release(); voice = null; super.onDestroy() }
    override fun onWindowFocusChanged(f: Boolean) { super.onWindowFocusChanged(f); if (f) immersive() }
    @Suppress("DEPRECATION") private fun immersive() {
        if (!AppPrefs(this).fullscreen) return
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }
}
