package com.mrt.jarvis.diagnostics

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.mrt.jarvis.R
import com.mrt.jarvis.can.CanEnvironmentProbe
import com.mrt.jarvis.can.CanState
import com.mrt.jarvis.vehicle.VehicleDataRepository
import java.text.SimpleDateFormat
import java.util.*

class DiagnosticsActivity : AppCompatActivity() {
    private lateinit var tv: TextView
    private var touch = "-"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_diagnostics)
        tv = findViewById(R.id.tvDiag)
        VehicleDataRepository.can.observe(this) { render() }  // event-driven
    }
    @SuppressLint("ClickableViewAccessibility")
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) { touch = "x:${e.rawX.toInt()} y:${e.rawY.toInt()}"; render() }
        return super.dispatchTouchEvent(e)
    }

    private fun render() {
        val s = VehicleDataRepository.canStats()
        val probe = CanEnvironmentProbe.run(this)
        val dm = DisplayMetrics().also { @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(it) }
        val f = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        tv.text = buildString {
            appendLine("CAN STATUS"); appendLine(if (s.state == CanState.CONNECTED) "CONNECTED" else s.state.name)
            s.reason?.let { appendLine("Reason: $it") }
            appendLine("Provider: ${s.provider}"); appendLine("Protocol: ${s.protocol}")
            appendLine("RX: ${s.rx}   TX: ${s.tx}   Errors: ${s.errors}")
            appendLine("Last frame: " + (s.lastFrame?.let { "ID 0x%03X @ %s".format(it.id, f.format(Date(it.timestamp))) } ?: "-"))
            appendLine("Data: " + (s.lastFrame?.hex() ?: "-"))
            appendLine(); appendLine("== ENVIRONMENT PROBE ==")
            appendLine("Installed CAN apps: ${probe.installedCanApps.ifEmpty { listOf("none") }}")
            appendLine("SocketCAN interfaces: ${probe.socketCan.ifEmpty { listOf("none") }}")
            appendLine("Serial devices: ${probe.serialDevices.ifEmpty { listOf("none") }}")
            appendLine("Readable by app (no root): ${probe.readableSerial.ifEmpty { listOf("none") }}")
            appendLine(); appendLine("== SYSTEM ==")
            appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} / ${Build.HARDWARE}")
            appendLine("Board: ${Build.BOARD}  Display build: ${Build.DISPLAY}")
            appendLine("Screen: ${dm.widthPixels}x${dm.heightPixels} @ ${dm.densityDpi}dpi")
            appendLine("RAM class: ${(getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).memoryClass} MB")
            appendLine("MCU: read from vendor settings (not exposed via public API)")
            appendLine(); appendLine("== TOUCH =="); appendLine(touch)
        }
    }
}
