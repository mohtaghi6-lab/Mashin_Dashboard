package com.mrt.jarvis.can

import android.content.Context
import com.mrt.jarvis.R
import com.mrt.jarvis.settings.AppPrefs
import com.mrt.jarvis.vehicle.VehicleData

class CanManager(private val ctx: Context, private val sink: (VehicleData.() -> VehicleData) -> Unit,
                 private val statsSink: (CanStats) -> Unit) : CanListener {
    private var provider: CanProvider? = null
    private var stats = CanStats()
    private val decoder = CanDecoder()

    fun start() {
        val prefs = AppPrefs(ctx)
        provider = when {
            prefs.demoMode -> DemoProvider()
            prefs.canAction.isNotBlank() -> BroadcastCanProvider(ctx, prefs.canAction.trim())
            else -> NoCanProvider(ctx.getString(R.string.can_reason_none))
        }
        stats = CanStats(provider = provider!!.name, protocol = provider!!.protocol)
        statsSink(stats)
        provider!!.start(this)
    }
    fun stop() { provider?.stop(); provider = null }

    override fun onFrame(msg: CanMessage) {
        stats = stats.copy(rx = stats.rx + 1, lastFrame = msg); statsSink(stats)
        val d = decoder.decode(msg)
        if (d.isNotEmpty()) sink { copy(speedKmh = d["speed"] ?: speedKmh, rpm = d["rpm"] ?: rpm) }
    }
    override fun onVehicle(update: (VehicleData) -> VehicleData) = sink { update(this) }
    override fun onState(state: CanState, reason: String?) {
        if (stats.state == state && stats.reason == reason) return
        stats = stats.copy(state = state, reason = reason); statsSink(stats)
    }
}
