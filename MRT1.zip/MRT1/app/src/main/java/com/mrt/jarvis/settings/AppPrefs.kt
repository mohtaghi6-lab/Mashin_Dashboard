package com.mrt.jarvis.settings

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class AppPrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("mrt_prefs", Context.MODE_PRIVATE)
    /** API key lives in Keystore-backed encrypted storage, never in source code. */
    private val secure = runCatching {
        EncryptedSharedPreferences.create(ctx, "mrt_secure",
            MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }.getOrNull()

    var startOnBoot by bool("boot", true)
    var fullscreen by bool("fullscreen", true)
    var demoMode by bool("demo", false)          // OFF by default
    var ttsEnabled by bool("tts", true)
    var wakeWord by bool("wake", false)
    var aiEnabled by bool("ai", false)
    var canAction by str("can_action", "")
    var vehicleModel by str("vehicle", "Peugeot Pars 1392/1393")
    var aiModel by str("model", "gpt-4o-mini")
    var redline: Int get() = p.getInt("redline", 6000); set(v) = p.edit().putInt("redline", v).apply()
    var brightness: Int get() = p.getInt("bright", -1); set(v) = p.edit().putInt("bright", v).apply()
    var apiKey: String
        get() = secure?.getString("openai", "") ?: ""
        set(v) { secure?.edit()?.putString("openai", v)?.apply() }

    private fun bool(k: String, def: Boolean) = object : kotlin.properties.ReadWriteProperty<Any, Boolean> {
        override fun getValue(t: Any, pr: kotlin.reflect.KProperty<*>) = p.getBoolean(k, def)
        override fun setValue(t: Any, pr: kotlin.reflect.KProperty<*>, v: Boolean) = p.edit().putBoolean(k, v).apply()
    }
    private fun str(k: String, def: String) = object : kotlin.properties.ReadWriteProperty<Any, String> {
        override fun getValue(t: Any, pr: kotlin.reflect.KProperty<*>) = p.getString(k, def) ?: def
        override fun setValue(t: Any, pr: kotlin.reflect.KProperty<*>, v: String) = p.edit().putString(k, v).apply()
    }
}
