package com.mrt.jarvis.can

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import com.mrt.jarvis.vehicle.VehicleData

/** Default: nothing connected. Honest "not available". */
class NoCanProvider(private val reason: String) : CanProvider {
    override val name = "none"
    override val protocol = "-"
    override fun start(listener: CanListener) = listener.onState(CanState.DISCONNECTED, reason)
    override fun stop() {}
}

/**
 * Listens to a vendor broadcast action entered by the user in Settings (discovered with
 * logcat on the real unit). Reads only the extras actually present in each intent.
 * Extra keys can be adapted once the vendor's real keys are known.
 */
class BroadcastCanProvider(private val ctx: Context, private val action: String) : CanProvider {
    override val name = "Vendor broadcast ($action)"
    override val protocol = "Intent"
    private var rx: BroadcastReceiver? = null

    override fun start(listener: CanListener) {
        listener.onState(CanState.CONNECTING)
        rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val ex = i.extras ?: return
                fun f(vararg k: String): Float? = k.firstNotNullOfOrNull { key ->
                    if (ex.containsKey(key)) (ex.get(key) as? Number)?.toFloat() else null }
                fun b(k: String): Boolean? = if (ex.containsKey(k)) ex.getBoolean(k) else null
                ex.getByteArray("frame")?.let { listener.onFrame(CanMessage(ex.getInt("id"), it)) }
                listener.onVehicle { v -> v.copy(
                    speedKmh = f("speed") ?: v.speedKmh, rpm = f("rpm") ?: v.rpm,
                    engineTempC = f("water_temp", "engine_temp") ?: v.engineTempC,
                    fuelPercent = f("fuel") ?: v.fuelPercent, batteryVolt = f("battery", "voltage") ?: v.batteryVolt,
                    outsideTempC = f("outside_temp") ?: v.outsideTempC, tripKm = f("trip") ?: v.tripKm,
                    odometerKm = f("odometer", "mileage") ?: v.odometerKm,
                    reverse = b("reverse") ?: v.reverse, parkingBrake = b("handbrake") ?: v.parkingBrake,
                    doorOpen = b("door") ?: v.doorOpen, seatBelt = b("seatbelt") ?: v.seatBelt) }
                listener.onState(CanState.CONNECTED)
            }
        }
        ctx.registerReceiver(rx, IntentFilter(action))
    }
    override fun stop() { rx?.let { runCatching { ctx.unregisterReceiver(it) } }; rx = null }
}

/** UI TEST ONLY. Off by default and clearly flagged on screen. */
class DemoProvider : CanProvider {
    override val name = "DEMO"
    override val protocol = "demo"
    private val h = Handler(Looper.getMainLooper())
    private var t = 0f
    private var l: CanListener? = null
    private val tick = object : Runnable { override fun run() {
        t += 0.1f
        val sp = 60f + 40f * kotlin.math.sin(t / 4)
        l?.onVehicle { VehicleData(speedKmh = sp, rpm = 1200f + sp * 25, engineTempC = 90f, fuelPercent = 67f,
            batteryVolt = 13.8f, outsideTempC = 24f, tripKm = 12.4f, gear = "D", lights = true,
            engineRunning = true, seatBelt = true, isDemo = true) }
        h.postDelayed(this, 100)
    } }
    override fun start(listener: CanListener) { l = listener; listener.onState(CanState.CONNECTED, "demo"); h.post(tick) }
    override fun stop() { h.removeCallbacks(tick); l = null }
}
