package com.mrt.jarvis.settings

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.mrt.jarvis.R
import com.mrt.jarvis.ai.Net
import com.mrt.jarvis.diagnostics.DiagnosticsActivity
import com.mrt.jarvis.vehicle.VehicleDataRepository

class SettingsActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { AppPrefs(this) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_settings)
        root = findViewById(R.id.root)
        header(R.string.s_general)
        switch(R.string.s_start_boot, prefs.startOnBoot) { prefs.startOnBoot = it }
        switch(R.string.s_fullscreen, prefs.fullscreen) { prefs.fullscreen = it }
        seek(R.string.s_brightness, if (prefs.brightness < 0) 80 else prefs.brightness) { prefs.brightness = it }
        header(R.string.s_vehicle)
        val model = edit(R.string.s_vehicle_model, prefs.vehicleModel, false)
        val action = edit(R.string.s_can_action, prefs.canAction, false)
        val red = edit(R.string.s_redline, prefs.redline.toString(), false).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        switch(R.string.s_demo, prefs.demoMode) { prefs.demoMode = it }
        header(R.string.s_voice)
        switch(R.string.s_tts, prefs.ttsEnabled) { prefs.ttsEnabled = it }
        switch(R.string.s_wake, prefs.wakeWord) { prefs.wakeWord = it }
        header(R.string.s_ai)
        switch(R.string.s_ai_enable, prefs.aiEnabled) { prefs.aiEnabled = it }
        val key = edit(R.string.s_api_key, if (prefs.apiKey.isEmpty()) "" else "••••••••", true)
        val aiModel = edit(R.string.s_model, prefs.aiModel, false)
        label(getString(R.string.internet) + ": " + getString(if (Net.online(this)) R.string.online else R.string.offline))
        root.addView(Button(this).apply { setText(R.string.save); setOnClickListener {
            prefs.vehicleModel = model.text.toString(); prefs.canAction = action.text.toString()
            prefs.redline = red.text.toString().toIntOrNull() ?: 6000; prefs.aiModel = aiModel.text.toString()
            val k = key.text.toString(); if (k.isNotBlank() && !k.startsWith("•")) prefs.apiKey = k.trim()
            VehicleDataRepository.restart(this@SettingsActivity)
            Toast.makeText(this@SettingsActivity, R.string.saved, Toast.LENGTH_SHORT).show(); finish()
        } })
        root.addView(Button(this).apply { setText(R.string.diagnostics); setOnClickListener {
            startActivity(Intent(this@SettingsActivity, DiagnosticsActivity::class.java)) } })
    }

    private fun header(id: Int) = root.addView(TextView(this).apply { setText(id); textSize = 18f
        setTextColor(getColor(R.color.accent)); setPadding(0, 32, 0, 8) })
    private fun label(s: String) = root.addView(TextView(this).apply { text = s; setTextColor(getColor(R.color.text_dim)) })
    private fun switch(id: Int, v: Boolean, on: (Boolean) -> Unit) = root.addView(Switch(this).apply {
        setText(id); isChecked = v; setTextColor(getColor(R.color.text)); setOnCheckedChangeListener { _, c -> on(c) } })
    private fun seek(id: Int, v: Int, on: (Int) -> Unit) { label(getString(id)); root.addView(SeekBar(this).apply {
        max = 100; progress = v; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) on(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }) }
    private fun edit(id: Int, v: String, secret: Boolean): EditText { label(getString(id))
        return EditText(this).apply { setText(v); setTextColor(getColor(R.color.text)); textDirection = View.TEXT_DIRECTION_LTR
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }.also { root.addView(it) } }
}
