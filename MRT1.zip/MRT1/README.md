# MRT1 – Native Android Dashboard (Peugeot Pars 1392/1393)

Native Kotlin app (no WebView/browser) for the XY Auto head unit — Android 10, 2 GB RAM, 1080×600.
Luxury dark glass design, Persian RTL UI, hybrid Persian voice assistant **MRT / Jarvis**.

## Get the APK (easiest – no PC setup)
1. Create a GitHub repository and upload this folder.
2. Open the **Actions** tab → *Build APK* runs automatically.
3. Download the `MRT1-apk` artifact → copy `app-release.apk` to USB → install on the head unit
   (enable *Unknown sources*).

## Build locally
Android Studio (Hedgehog+) → Open folder → Build → Build APK(s). Or: `gradle :app:assembleRelease`
(JDK 17, Android SDK 34). Output: `app/build/outputs/apk/release/`.

## First run on the car
- Press Home and choose **MRT1** → *Always*: it becomes the launcher and starts on every boot
  (the most reliable way on Android 10). A BOOT_COMPLETED receiver is also included.
- Allow microphone when asked.

## OpenAI key (never in source code)
Settings (gear icon) → AI → paste key → enable AI → Save. Stored with Android Keystore
(EncryptedSharedPreferences). `secrets.properties.example` is only a reminder; real secrets are git-ignored.

## CAN bus — honest status
The app **never invents values**. With no accessible provider, everything shows `--` and
"CAN: در دسترس نیست".
- Long-press the gear icon → **Diagnostics**: probes installed vendor CAN apps (e.g. `com.xygala.canbus`),
  SocketCAN interfaces and serial devices readable without root, plus screen size and touch coordinates.
- If the vendor app broadcasts vehicle data, find the action with `adb logcat` and enter it in
  Settings → Vehicle → *Vendor broadcast action*. `BroadcastCanProvider` reads the extras present.
- To add raw frame decoding, add verified `CanSignal`s in `CanDecoder` (Pars IDs must be captured on the car).
- New sources = implement `CanProvider`; the dashboard does not change.

## Voice
Uses the speech-recognition service installed on the unit (fa-IR, prefer offline) and the installed TTS
engine for Persian. If none is installed the app says so. Vehicle, media, volume and screen commands are
handled locally (`CommandRouter`) and never sent to the cloud; only general questions go to OpenAI when online.
Wake word "MRT" is an extension point; push-to-talk (mic button or steering voice key) is the default.

## Demo mode
Settings → Vehicle → Demo mode (OFF by default). Shows an orange banner; for UI testing only.

## Safety
No root, no system-partition, MCU, CAN-firmware, camera or radio changes. Volume/media/call keys pass
through to the factory system; reverse camera stays with the factory implementation.
All texts are in `res/values/strings.xml` and read with `getString(R.string.x)` — no raw resource IDs.

## Structure
```
app/src/main/java/com/mrt/jarvis/
  MainActivity.kt          dashboard screen
  dashboard/               GaugeView, StatusIndicatorsView, DashboardViewModel
  can/                     CanMessage/CanSignal/CanStats, CanDecoder, CanProvider, CanManager, providers, probe
  vehicle/                 VehicleData, VehicleDataRepository
  voice/                   VoiceManager (STT+TTS), AssistantController
  ai/                      CommandRouter, OpenAIService, Net
  settings/                SettingsActivity, AppPrefs (encrypted key)
  diagnostics/             DiagnosticsActivity
  boot/                    BootReceiver
```
